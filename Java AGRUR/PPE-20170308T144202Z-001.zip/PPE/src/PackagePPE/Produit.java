package PackagePPE;
import java.util.*;
public class Produit {
    private String variete; //Variété de noix
    private String type; //Type de noix
    private int calibre; //Calibre des noix
    
    public Produit(String uneVariete, String unType, int unCalibre){
        this.variete = uneVariete;
        this.type = unType;
        this.calibre = unCalibre;
    }
    
    public String getVariete(){
        return this.variete;
    }
    
    public String getType(){
        return this.type;
    }
    
    public int getCalibre(){
        return this.calibre;
    }
}
