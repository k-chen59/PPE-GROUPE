package PackagePPE;
import java.util.*;
public class Distributeur {
    private String id; //Identifiant du Distributeur 
    private String nom; //Nom du Distributeur
    private ArrayList<Commande> lesCommandes; //Toutes les commandes du Distributeur
    
    public Distributeur(String unId, String unNom){
        this.id = unId;
        this.nom = unNom;
    }
    
    public String getId(){
        return this.id;
    }
    
    public ArrayList<Commande> getCommandes(){
        return this.lesCommandes;
    }
    /*
    public ArrayList<Commande> getCommandesEnCours(){
        
    }
    */
}
