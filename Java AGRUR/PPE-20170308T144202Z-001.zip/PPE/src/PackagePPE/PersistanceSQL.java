package PackagePPE;
import java.util.*;
public class PersistanceSQL {
    PersistanceSQL(String ipBase, int port, String nomBaseDeDonnée){
        
    }
    
    public void RangerDansBase(Object unObjet){
        
    }
    
}
