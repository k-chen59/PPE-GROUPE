package PackagePPE;
import java.util.*;
public class Commande {
    private int id; //Identifiant de la commande
    private Produit leProduit; //Le produit commandé (catégorie de noix)
    private String conditionnement; //Type de conditionnement
    private int quantite; //Quantité de produits conditionnés commandée
    private Date dateConditionnement; //Date de conditionnement de la commande
    private Date dateEnvoi; //Date d'envoi de la commande
    
    public Commande(int unId, Produit unProduit, String unConditionnement, int uneQuantite, Date uneDateConditionnement, Date uneDateEnvoi){
        this.id = unId;
        this.leProduit = unProduit;
        this.conditionnement = unConditionnement;
        this.quantite = uneQuantite;
        this.dateConditionnement = uneDateConditionnement;
        this.dateEnvoi = uneDateEnvoi;
    }
    
    public int getId(){
        return this.id;
    }
    
    public Produit getProduit(){
        return this.leProduit;
    }
    
    public String getConditionnement(){
        return this.conditionnement;
    }
    
    public int getQuantite(){
        return this.quantite;
    }
    
    public Date getDateConditionnement(){
        return this.dateConditionnement;
    }
    
    public Date getDateEnvoi(){
        return this.dateEnvoi;
    }
    
    public boolean enCours(){
        boolean expediee = false;
        //if(){
        
        //}
        return expediee;
    }
    /*
    public String XmlCommande(){
        
    }
    */
}
