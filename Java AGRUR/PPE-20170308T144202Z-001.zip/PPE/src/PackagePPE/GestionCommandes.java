package PackagePPE;
import java.util.*;
public class GestionCommandes {
    private PersistanceSQL donnees;
    
    public GestionCommandes(PersistanceSQL lesDonnees){
        this.donnees = lesDonnees;
    }
    /*
    public Distributeur getDistributeur(String idDistributeur){
        
    }
    */
    
   /*
    public String XmlNonLivrees(Distributeur unDistributeur){
        
    }
    */ 
}
